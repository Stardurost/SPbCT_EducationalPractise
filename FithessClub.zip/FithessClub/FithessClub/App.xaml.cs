﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;

namespace FithessClub
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        public static readonly Entites.FITNESSEntities3 DataBase = new Entites.FITNESSEntities3();

        public static Entites.User CurrentUser = null;

    }
}
