﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace FithessClub.Pages
{
    /// <summary>
    /// Interaction logic for AddOrEditServicesPage.xaml
    /// </summary>
    public partial class AddOrEditClientPage : Page
    {
        bool Edit = false;
        private Entites.Trainer _currentTrainer = null;
        public AddOrEditClientPage()
        {
            Edit = false;
            InitializeComponent();
        }

        public AddOrEditClientPage(Entites.Trainer trainer)
        {
            Edit = true;
            InitializeComponent();
            Title = "Редактирование тренера";
            _currentTrainer = trainer;
            TBoxName.Text = _currentTrainer.Name;
            TBoxNumberPassport.Text = _currentTrainer.NumberPassport;
            TBoxNymberPhone.Text = _currentTrainer.NumberPhone;
            TBoxPassword.Text = _currentTrainer.Password;
            TBoxDateB.Text = _currentTrainer.DateBirth.ToString();
            TBoxGender.Text = _currentTrainer.Gender;
            

        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new ClientPage());
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            var errorMessage = CheckError();
            if (errorMessage.Length > 0)
            {
                MessageBox.Show(errorMessage, "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else 
            {
                var trainer = new Entites.Trainer
                {
                    Name = TBoxName.Text,
                    NumberPhone = TBoxNymberPhone.Text,
                    NumberPassport = TBoxNumberPassport.Text,
                    DateBirth = DateTime.Parse(TBoxDateB.Text),
                    Password = TBoxPassword.Text,
                    Gender = TBoxGender.Text
                };
                App.DataBase.Trainers.Add(trainer);
                App.DataBase.SaveChanges();
                MessageBox.Show("Новая запись создана");
                NavigationService.Navigate(new ClientPage());
            }
        }

     

        private string CheckError()  // проверка заполнения полей
        { 
            var ErrorBuilder = new StringBuilder();

            

            if (string.IsNullOrEmpty(TBoxName.Text)) // проверка заполнения обязаельных полей 
            {
                ErrorBuilder.AppendLine("- ФИО обязательно для заполнения");
            }

            if (string.IsNullOrEmpty(TBoxNumberPassport.Text))
            {
                ErrorBuilder.AppendLine("- Номер паспорта обязателен для заполнения");
            }

            var currentTrainer = App.DataBase.Trainers.ToList() 
                .FirstOrDefault(p => p.NumberPassport == TBoxNumberPassport.Text);
                // поиск дубликатов
            if (currentTrainer != null && Edit == false) 
            {
                ErrorBuilder.AppendLine("- Данные паспорта не уникальны");
            }
            
            
            if (TBoxDateB.Text.Length > 10 && Edit == false) //проверка формата даты
            { 
                ErrorBuilder.AppendLine("- Неверный формат даты. Введите дату в формате ГГГГ-ММ-ДД");
            };

            if (ErrorBuilder.Length > 0)
            {
                ErrorBuilder.Insert(0, "Устраните ошибки:\n");
            }
            string NumberP = "аааааааааа";
            if (NumberP.Length >= TBoxNymberPhone.Text.Length)
            {
                ErrorBuilder.AppendLine("- Невернй формат телефона. Введите цифры без пробелов и тире");
            }
            string NumberPas = "aaaaaaaaaa";
            if (NumberPas.Length != TBoxNumberPassport.Text.Length)
            {
                ErrorBuilder.AppendLine("- Неверный формат номера паспорта. Введите цифры без пробелов и тире");
            }
            string Gende = "a";
            if (Gende.Length != TBoxGender.Text.Length)
            {
                ErrorBuilder.AppendLine("- Неверный формат ввода пола. Введите одну букву: м или ж");
            }
            return ErrorBuilder.ToString();
        }
   
    }
}
