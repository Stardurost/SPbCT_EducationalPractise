﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace FithessClub.Pages
{
    /// <summary>
    /// Interaction logic for LoginPage.xaml
    /// </summary>
    public partial class LoginPage : Page
    {
        public LoginPage()
        {
            InitializeComponent();

        }

        private void BtnEnter_Click(object sender, RoutedEventArgs e)
        {
            
                var currentUser = App.DataBase.Users.FirstOrDefault(P => P.Login == TBoxLogin.Text && P.Password == TBoxPassword.Password);
           
            if (currentUser != null)
            {
                App.CurrentUser = currentUser;
                if (currentUser.RoleId == 1)
                { NavigationService.Navigate(new MainPage());}
                else if (currentUser.RoleId == 2)
                { NavigationService.Navigate(new StartPage()); }
                else if (currentUser.RoleId == 3)
                { NavigationService.Navigate(new StartPage()); }
            }
            else 
            {
                MessageBox.Show("Неверный логин и/или пароль");
            }
            
        }

        private void BtnrEG_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Registration());
        }



    }
}
