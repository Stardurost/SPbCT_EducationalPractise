﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace FithessClub.Pages
{
    /// <summary>
    /// Interaction logic for ServicesPage.xaml
    /// </summary>
    public partial class ClientPage : Page
    {
        public ClientPage()
        {
            InitializeComponent();
            

            LViewTrainers.ItemsSource = App.DataBase.Trainers.ToList();
         

        }

        private void Create_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new AddOrEditClientPage());
            UpdateServices();
        }

    

        private void Rename_Click(object sender, RoutedEventArgs e)
        {

            var button = sender as Button;
            var currentTrainer = button.DataContext as Entites.Trainer;
            NavigationService.Navigate(new AddOrEditClientPage(currentTrainer));
            UpdateServices();
        }

        private void Delete_Click(object sender, RoutedEventArgs e)
        {
            var button = sender as Button;
            var currentTrainer = button.DataContext as Entites.Trainer;
            if(MessageBox.Show("Запись о сотруднике будет удалена! Вы уверены?","Внимание",MessageBoxButton.YesNo,MessageBoxImage.Warning)==MessageBoxResult.Yes)
            {
                App.DataBase.Trainers.Remove(currentTrainer);
                App.DataBase.SaveChanges();
                UpdateServices();

            }
            //LViewTrainers.SelectedItem as Entites.
        }

        private void UpdateServices()
        { 
            var trainers = App.DataBase.Trainers.ToList();

            LViewTrainers.ItemsSource = trainers;


        }
    }
}
